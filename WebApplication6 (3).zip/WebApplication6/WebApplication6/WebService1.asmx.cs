﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using System.Web.Services;
using System.Data.SqlClient;
using System.Data;
using System.Text;

namespace WebApplication6
{
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
    [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {
        public string DataTableToJSONWithStringBuilder(DataTable table)
        {
            var JSONString = new StringBuilder();
            if (table.Rows.Count > 0)
            {
                JSONString.Append("[");
                for (int i = 0; i < table.Rows.Count; i++)
                {
                    JSONString.Append("{");
                    for (int j = 0; j < table.Columns.Count; j++)
                    {
                        if (j < table.Columns.Count - 1)
                        {
                            JSONString.Append("\"" + table.Columns[j].ColumnName.ToString() + "\":" + "\"" + table.Rows[i][j].ToString() + "\",");
                        }
                        else if (j == table.Columns.Count - 1)
                        {
                            JSONString.Append("\"" + table.Columns[j].ColumnName.ToString() + "\":" + "\"" + table.Rows[i][j].ToString() + "\"");
                        }
                    }
                    if (i == table.Rows.Count - 1)
                    {
                        JSONString.Append("}");
                    }
                    else
                    {
                        JSONString.Append("},");
                    }
                }
                JSONString.Append("]");
            }
            return JSONString.ToString();
        }

        
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Get_Users()
        {
            //   string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;

            SqlConnection con;
            con = new SqlConnection(WebApplication6.Properties.Settings.Default.Setting);
            using (con)
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM Customer1"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;
                        using (DataTable dt = new DataTable())
                        {
                            dt.TableName = "Customer1";
                            sda.Fill(dt);

                            return DataTableToJSONWithStringBuilder(dt); ;
                        }
                    }
                }
            }
        }


        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public string Get_Page(String pageno, String pagesize)
        {
            //   string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;

            var page_size = 10;
            var page_num = Convert.ToInt32(pageno);
            SqlConnection con;
            con = new SqlConnection(WebApplication6.Properties.Settings.Default.Setting);
            using (con)
            {
                using (SqlCommand cmd = new SqlCommand("Select * From Customer1 Order by Id OFFSET " + ((page_num-1) * page_size) + " Rows Fetch Next " + page_size + " rows only"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;
                        using (DataTable dt = new DataTable())
                        {
                            dt.TableName = "Customer1";
                            sda.Fill(dt);

                            return DataTableToJSONWithStringBuilder(dt); ;
                        }
                    }
                }
            }
        }
    }
}
